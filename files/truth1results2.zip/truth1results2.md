## raw

### raw_elements plus

TP = 278, FN = 37, FP = 431
PRECISION = 0.3921
RECALL = 0.8825

### raw_relation plus

TP = 95, FN = 101, FP = 274
PRECISION = 0.2575
RECALL = 0.4847

## by_dict

### by_dict_elements plus

TP = 199, FN = 116, FP = 98
PRECISION = 0.6700
RECALL = 0.6317


### by_dict relation plus

TP = 125, FN = 71, FP = 244
PRECISION = 0.3388
RECALL = 0.6378

## by_article

### by_article_elements plus

TP = 166, FN = 149, FP = 40
PRECISION = 0.8058
RECALL = 0.5270


### by_artticle_relations plus

TP = 142, FN = 54, FP = 227
PRECISION = 0.3848
RECALL = 0.7245

## by_both

### by_both_elements plus

TP = 226, FN = 89, FP = 102
PRECISION = 0.6890
RECALL = 0.7175

### by_both_relation plus

TP = 143, FN = 53, FP = 226
PRECISION = 0.3875
RECALL = 0.7296

## validation model outputs

### validation model outputs elements plus

TP = 278, FN = 37, FP = 431
PRECISION = 0.3921
RECALL = 0.8825

### validation model outputs relations plus

TP = 97, FN = 99, FP = 272
PRECISION = 0.2629
RECALL = 0.4949

